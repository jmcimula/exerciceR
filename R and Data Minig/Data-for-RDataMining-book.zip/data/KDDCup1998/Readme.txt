These data are a sample of the first 10,000 rows only. 

The complete original datasets can be downloaded at http://www.sigkdd.org/kddcup/index.php?section=1998&method=data.