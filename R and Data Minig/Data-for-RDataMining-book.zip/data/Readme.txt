Datasets for book "R and Data Mining: Examples and Case Studies"


Notes on KDD Cup 1998 data:
Regarding data of KDD Cup 1998 in this ZIP archive, the training dataset "cup98LRN.txt" contains only the first 10,000 rows out of the 95,412 rows in the original one. Similarly, the validation dataset "cup98VAL.txt" also contains the first 10,000 rows only and "valtargt.txt" provides the actual values of target variables of those 10,000 rows. Readers who want to try the complete original datasets are suggested to download them at http://www.sigkdd.org/kddcup/index.php?section=1998&method=data.


Contact: Yanchang Zhao
Email: yanchang@rdatamining.com
Website: http://www.rdatamining.com
Group on LinkedIn: http://group.rdatamining.com